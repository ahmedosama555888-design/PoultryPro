#include "basiccost.h"

BasicCosts::BasicCosts(double rent, double electricity, double chickPrice, double wages, int chicks) {
    farmRent = rent;
    electricityCost = electricity;
    chickPricePerUnit = chickPrice;
    laborWages = wages;
    totalChicks = chicks;
}

double BasicCosts::getTotalFixedCosts() {
    return farmRent + electricityCost + (chickPricePerUnit * totalChicks) + laborWages;
}

QString BasicCosts::printSummary() {
    return "الإيجار: " + QString::number(farmRent) +
           " | الكهرباء: " + QString::number(electricityCost) +
           " | إجمالي التكاليف الثابتة: " + QString::number(getTotalFixedCosts());
}