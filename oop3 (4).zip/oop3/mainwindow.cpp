#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "basiccost.h"
#include "feedmanager.h"
#include "mortalitytracker.h"
#include "productionreport.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    ui->tabWidget->setCurrentIndex(0);
    ui->vaccineTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

MainWindow::~MainWindow() {
    if (mortalityTracker) delete mortalityTracker;
    delete ui;
}

void MainWindow::on_btn_start_cycle_clicked() {
    // 1. استلام البيانات من الواجهة
    farmRent = ui->input_farm_rent->value();
    chickPrice = ui->input_chick_price->value();
    initialChicks = ui->input_total_chicks->value();
    operatingCosts = ui->input_operating_costs->value();

    // 2. تهيئة البيانات وإنشاء كائن التتبع
    currentDay = 0;
    vaccineTotal = 0;
    if (mortalityTracker) delete mortalityTracker;
    mortalityTracker = new MortalityTracker(initialChicks);

    // 3. تحديث واجهة المستخدم
    ui->lbl_current_age->setText("0");
    ui->lbl_remaining_birds->setText(QString::number(mortalityTracker->getRemainingBirds()));
    ui->lbl_death_rate_percent->setText("إجمالي عدد النافق: 0");
    ui->vaccineTable->setRowCount(0);

    ui->tabWidget->setCurrentIndex(1);
}

void MainWindow::on_btn_feed_next_clicked() {
    feedCosts = ui->input_feed_badi->value() +
                ui->input_feed_nami->value() +
                ui->input_finisher_price->value();
    ui->tabWidget->setCurrentIndex(2);
}

void MainWindow::on_btn_next_day_clicked() {
    currentDay++;
    int deadToday = ui->sb_natural_mortality->value() + ui->sb_sick_mortality->value();

    // تسجيل النافق وتحديث العدد المتبقي في الواجهة أثناء الدورة
    if (mortalityTracker) {
        mortalityTracker->recordMortality(deadToday);
        int remaining = mortalityTracker->getRemainingBirds();
        int totalDeadSoFar = initialChicks - remaining;

        ui->lbl_remaining_birds->setText(QString::number(remaining));
        ui->lbl_death_rate_percent->setText("إجمالي عدد النافق: " + QString::number(totalDeadSoFar));
    }

    ui->lbl_current_age->setText(QString::number(currentDay));
    ui->sb_natural_mortality->setValue(0);
    ui->sb_sick_mortality->setValue(0);
}

void MainWindow::on_btn_add_vaccine_clicked() {
    QString name = ui->txt_vac_name->text();
    double price = ui->sb_vac_cost->value();
    int day = ui->sb_vac_day->value();

    if (name.isEmpty()) return;

    int row = ui->vaccineTable->rowCount();
    ui->vaccineTable->insertRow(row);
    ui->vaccineTable->setItem(row, 0, new QTableWidgetItem(QString::number(day)));
    ui->vaccineTable->setItem(row, 1, new QTableWidgetItem(name));
    ui->vaccineTable->setItem(row, 2, new QTableWidgetItem("تم"));
    ui->vaccineTable->setItem(row, 3, new QTableWidgetItem(QString::number(price, 'f', 2)));

    vaccineTotal += price;
    ui->txt_vac_name->clear();
    ui->sb_vac_cost->setValue(0);
}

void MainWindow::on_btn_finish_cycle_clicked() {
    // حساب التكاليف الإجمالية
    double totalChicksPurchase = initialChicks * chickPrice;
    double totalExpenses = farmRent + operatingCosts + totalChicksPurchase + feedCosts + vaccineTotal;

    // إنشاء التقرير النهائي
    FarmReport* report = new ProductionReport(
        ui->sb_final_weight->value(),
        ui->sb_market_price->value(),
        totalExpenses,
        currentDay
        );

    ProductionReport* prodReport = dynamic_cast<ProductionReport*>(report);
    double revenue = prodReport->calculateRevenue();
    double netProfit = report->calculateNetProfit();

    // عرض النتائج المالية
    ui->lbl_total_revenue->setText(QString::number(revenue, 'f', 2) + " ج.م");
    ui->lbl_total_costs->setText(QString::number(totalExpenses, 'f', 2) + " ج.م");
    ui->lbl_final_profit->setText(QString::number(netProfit, 'f', 2) + " ج.م");

    // --- تعديل حساب المتبقي بدلاً من المتوفى ---
    if (mortalityTracker) {
        // جلب عدد الطيور الحية المتبقية مباشرة
        int remainingBirds = mortalityTracker->getRemainingBirds();
        ui->lbl_total_dead_count->setText(QString::number(remainingBirds) + " طائر");

        // ملاحظة: قمنا باستخدام نفس الـ Label (lbl_total_dead_count)
        // لكننا وضعنا فيه قيمة المتبقي بناءً على طلبك.
    } else {
        ui->lbl_total_dead_count->setText("0 طائر");
    }

    ui->lbl_total_vac_cost->setText(QString::number(vaccineTotal, 'f', 2) + " ج.م");

    // تنسيق لون الربح/الخسارة
    if (netProfit >= 0) ui->lbl_final_profit->setStyleSheet("color: #27ae60; font-weight: bold;");
    else ui->lbl_final_profit->setStyleSheet("color: #e74c3c; font-weight: bold;");

    delete report;
    ui->tabWidget->setCurrentIndex(4);
}