#ifndef MORTALITYTRACKER_H
#define MORTALITYTRACKER_H
#include <QString>

class MortalityTracker {
private:
    int initialBirds;
    int totalDeaths;

public:
    MortalityTracker(int birds);
    void recordMortality(int count);
    double getMortalityRate();
    int getRemainingBirds();
};
#endif