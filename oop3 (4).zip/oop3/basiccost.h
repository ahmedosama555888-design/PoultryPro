#ifndef BASICCOST_H
#define BASICCOST_H
#include <QString>

class BasicCosts {
private:
    double farmRent;
    double electricityCost;
    double chickPricePerUnit;
    double laborWages;
    int totalChicks;

public:
    BasicCosts(double rent, double electricity, double chickPrice, double wages, int chicks);
    double getTotalFixedCosts();
    QString printSummary();
};
#endif