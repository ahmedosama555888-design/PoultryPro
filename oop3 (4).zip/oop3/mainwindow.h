#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include "mortalitytracker.h" // إضافة المكتبة الخاصة بـ MortalityTracker

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btn_start_cycle_clicked();
    void on_btn_feed_next_clicked();
    void on_btn_next_day_clicked();
    void on_btn_add_vaccine_clicked();
    void on_btn_finish_cycle_clicked();

private:
    Ui::MainWindow *ui;

    // --- المتغيرات التي تخزن البيانات ---
    double farmRent = 0.0;
    double chickPrice = 0.0;
    double operatingCosts = 0.0;
    int initialChicks = 0;
    double feedCosts = 0.0;
    double vaccineTotal = 0.0;
    int currentDay = 0;
    int totalDead = 0;

    // --- إضافة كائن الـ MortalityTracker ---
    // قمنا بوضعه هنا لكي يتمكن البرنامج من استخدامه في أي مكان داخل الكلاس
    MortalityTracker* mortalityTracker = nullptr;
};

#endif // MAINWINDOW_H