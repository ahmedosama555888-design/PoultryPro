#include "mortalitytracker.h"

MortalityTracker::MortalityTracker(int birds) : initialBirds(birds), totalDeaths(0) {}

void MortalityTracker::recordMortality(int count) {
    totalDeaths += count;
}

double MortalityTracker::getMortalityRate() {
    if (initialBirds == 0) return 0.0;
    return (double(totalDeaths) / initialBirds) * 100.0;
}

int MortalityTracker::getRemainingBirds() {
    return initialBirds - totalDeaths;
}