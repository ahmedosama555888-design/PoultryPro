#ifndef FEEDMANAGER_H
#define FEEDMANAGER_H

class FeedManager {
private:
    enum FeedType { STARTER, GROWER, FINISHER };
    double starterPrice;
    double growerPrice;
    double finisherPrice;
    double dailyConsumptionKg;

public:
    FeedManager(double starter, double grower, double finisher, double dailyKg);
    FeedType getCurrentFeedType(int day);
    double getCurrentFeedPrice(int day);
    double getDailyCost(int day, int birds);
    double getTotalFeedCost(int totalDays, int birds);
};
#endif