#include "feedmanager.h"

FeedManager::FeedManager(double starter, double grower, double finisher, double dailyKg) {
    starterPrice = starter;
    growerPrice = grower;
    finisherPrice = finisher;
    dailyConsumptionKg = dailyKg;
}

FeedManager::FeedType FeedManager::getCurrentFeedType(int day) {
    if (day <= 40) return STARTER;
    else if (day <= 70) return GROWER;
    else return FINISHER;
}

double FeedManager::getCurrentFeedPrice(int day) {
    FeedType type = getCurrentFeedType(day);
    if (type == STARTER) return starterPrice;
    else if (type == GROWER) return growerPrice;
    return finisherPrice;
}

double FeedManager::getDailyCost(int day, int birds) {
    return dailyConsumptionKg * birds * (getCurrentFeedPrice(day) / 1000.0);
}

double FeedManager::getTotalFeedCost(int totalDays, int birds) {
    double total = 0.0;
    for (int d = 1; d <= totalDays; d++) {
        total += getDailyCost(d, birds);
    }
    return total;
}