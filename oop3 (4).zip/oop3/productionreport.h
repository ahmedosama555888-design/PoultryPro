#ifndef PRODUCTIONREPORT_H
#define PRODUCTIONREPORT_H
#include <QString>

// --- Inheritance: Base Class ---
class FarmReport {
public:
    virtual ~FarmReport() {}
    virtual double calculateNetProfit() = 0;
};

// --- Derived Class ---
class ProductionReport : public FarmReport {
private:
    double totalProduction;
    double sellingPricePerKg;
    double totalExpenses;
    int cycleActualDays;

public:
    ProductionReport(double production, double price, double expenses, int days);
    double calculateNetProfit() override;
    double calculateRevenue();
    QString generateFullReport();
};
#endif