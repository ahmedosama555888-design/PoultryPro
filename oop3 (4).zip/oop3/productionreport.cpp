#include "productionreport.h"

ProductionReport::ProductionReport(double production, double price, double expenses, int days) {
    totalProduction = production;
    sellingPricePerKg = price;
    totalExpenses = expenses;
    cycleActualDays = days;
}

double ProductionReport::calculateRevenue() {
    return totalProduction * sellingPricePerKg;
}

double ProductionReport::calculateNetProfit() {
    return calculateRevenue() - totalExpenses;
}

QString ProductionReport::generateFullReport() {
    return "صافي الربح: " + QString::number(calculateNetProfit()) + " ج.م";
}